import os
from flask import Flask, request, jsonify
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.pydantic_v1 import BaseModel
from langchain.schema.output_parser import StrOutputParser
from langchain.schema.runnable import RunnableParallel, RunnablePassthrough
from flask_cors import CORS

from dotenv import load_dotenv
from data_preparation import load_data

load_dotenv()
os.environ['OPENAI_API_KEY'] = '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'

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

llm_lmstudio = ChatOpenAI(
    # openai_api_base="http://192.168.137.1:1234/v1",
    openai_api_base="http://localhost:1234/v1",
    openai_api_key="",                 
    model_name="mistral"
)

retriever = load_data()

template = """[Role]: As a government scheme consultant Chatbot, I specialize in assisting middle-income individuals in understanding and accessing appropriate government schemes.

Contexts:
{context}

Question: {question}
"""
prompt = ChatPromptTemplate.from_template(template)

chain = (
    RunnableParallel({"context": retriever, "question": RunnablePassthrough()})
    | prompt
    | llm_lmstudio
    | StrOutputParser()
)

class Question(BaseModel):
    __root__: str

chain = chain.with_types(input_type=Question)

# query = input('User: ')
# result = chain.invoke(query)
# print(result)

@app.route('/query', methods=['POST'])
def query():
    data = request.json
    user_input = data['query']
    result = chain.invoke(user_input)
    return jsonify({'response': result})

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False, port=5000, host="0.0.0.0")